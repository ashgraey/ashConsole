
export class Stage02{
    start(){  
        
    }
   
    update(){
       
       
    }

    draw(){
       
    }
   
}