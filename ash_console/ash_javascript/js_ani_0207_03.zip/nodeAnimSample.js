
export class NodeAnimSample{
    constructor(loopType, frameDelay , animationName , imageNameList){
        this.loopType = loopType;
        this.frameDelay = frameDelay;
        this.animationName = animationName;
        this.imageNameList = imageNameList;
    }
}